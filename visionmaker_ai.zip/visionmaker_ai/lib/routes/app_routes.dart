import 'package:flutter/material.dart';
import '../presentation/video_creation_screen/video_creation_screen.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/video_history_screen/video_history_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/subscription_screen/subscription_screen.dart';
import '../presentation/registration_screen/registration_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String videoCreation = '/video-creation-screen';
  static const String splash = '/splash-screen';
  static const String videoHistory = '/video-history-screen';
  static const String login = '/login-screen';
  static const String subscription = '/subscription-screen';
  static const String registration = '/registration-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    videoCreation: (context) => const VideoCreationScreen(),
    splash: (context) => const SplashScreen(),
    videoHistory: (context) => const VideoHistoryScreen(),
    login: (context) => const LoginScreen(),
    subscription: (context) => const SubscriptionScreen(),
    registration: (context) => const RegistrationScreen(),
    // TODO: Add your other routes here
  };
}
