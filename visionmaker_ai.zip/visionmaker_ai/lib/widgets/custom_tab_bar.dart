import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum CustomTabBarVariant {
  standard,
  pills,
  underline,
  segmented,
}

class CustomTabBar extends StatelessWidget implements PreferredSizeWidget {
  final List<String> tabs;
  final TabController? controller;
  final ValueChanged<int>? onTap;
  final CustomTabBarVariant variant;
  final bool isScrollable;
  final Color? indicatorColor;
  final Color? labelColor;
  final Color? unselectedLabelColor;
  final double? indicatorWeight;
  final EdgeInsetsGeometry? labelPadding;
  final EdgeInsetsGeometry? padding;

  const CustomTabBar({
    super.key,
    required this.tabs,
    this.controller,
    this.onTap,
    this.variant = CustomTabBarVariant.standard,
    this.isScrollable = false,
    this.indicatorColor,
    this.labelColor,
    this.unselectedLabelColor,
    this.indicatorWeight,
    this.labelPadding,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    switch (variant) {
      case CustomTabBarVariant.pills:
        return _buildPillsTabBar(context, colorScheme);
      case CustomTabBarVariant.underline:
        return _buildUnderlineTabBar(context, colorScheme);
      case CustomTabBarVariant.segmented:
        return _buildSegmentedTabBar(context, colorScheme);
      case CustomTabBarVariant.standard:
      default:
        return _buildStandardTabBar(context, colorScheme);
    }
  }

  Widget _buildStandardTabBar(BuildContext context, ColorScheme colorScheme) {
    return Container(
      padding: padding ?? const EdgeInsets.symmetric(horizontal: 16),
      child: TabBar(
        controller: controller,
        onTap: _handleTap,
        tabs: tabs.map((tab) => Tab(text: tab)).toList(),
        isScrollable: isScrollable,
        indicatorColor: indicatorColor ?? colorScheme.secondary,
        labelColor: labelColor ?? colorScheme.secondary,
        unselectedLabelColor:
            unselectedLabelColor ?? colorScheme.onSurfaceVariant,
        indicatorWeight: indicatorWeight ?? 2.0,
        labelPadding:
            labelPadding ?? const EdgeInsets.symmetric(horizontal: 16),
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: Colors.transparent,
      ),
    );
  }

  Widget _buildPillsTabBar(BuildContext context, ColorScheme colorScheme) {
    return Container(
      height: 48,
      padding:
          padding ?? const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        separatorBuilder: (context, index) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final isSelected = controller?.index == index;

          return GestureDetector(
            onTap: () => _handleTap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? (indicatorColor ?? colorScheme.secondary)
                    : colorScheme.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isSelected
                      ? (indicatorColor ?? colorScheme.secondary)
                      : colorScheme.outline.withAlpha(77),
                  width: 1,
                ),
              ),
              child: Text(
                tabs[index],
                style: TextStyle(
                  color: isSelected
                      ? colorScheme.onSecondary
                      : (unselectedLabelColor ?? colorScheme.onSurfaceVariant),
                  fontSize: 14,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildUnderlineTabBar(BuildContext context, ColorScheme colorScheme) {
    return Container(
      padding: padding ?? const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: colorScheme.outline.withAlpha(51),
            width: 1,
          ),
        ),
      ),
      child: TabBar(
        controller: controller,
        onTap: _handleTap,
        tabs: tabs.map((tab) => Tab(text: tab)).toList(),
        isScrollable: isScrollable,
        indicatorColor: indicatorColor ?? colorScheme.secondary,
        labelColor: labelColor ?? colorScheme.secondary,
        unselectedLabelColor:
            unselectedLabelColor ?? colorScheme.onSurfaceVariant,
        indicatorWeight: indicatorWeight ?? 3.0,
        labelPadding:
            labelPadding ?? const EdgeInsets.symmetric(horizontal: 16),
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: Colors.transparent,
      ),
    );
  }

  Widget _buildSegmentedTabBar(BuildContext context, ColorScheme colorScheme) {
    return Container(
      height: 48,
      margin: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withAlpha(77),
          width: 1,
        ),
      ),
      child: Row(
        children: tabs.asMap().entries.map((entry) {
          final index = entry.key;
          final tab = entry.value;
          final isSelected = controller?.index == index;
          final isFirst = index == 0;
          final isLast = index == tabs.length - 1;

          return Expanded(
            child: GestureDetector(
              onTap: () => _handleTap(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: isSelected
                      ? (indicatorColor ?? colorScheme.secondary)
                      : Colors.transparent,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(isFirst ? 11 : 0),
                    bottomLeft: Radius.circular(isFirst ? 11 : 0),
                    topRight: Radius.circular(isLast ? 11 : 0),
                    bottomRight: Radius.circular(isLast ? 11 : 0),
                  ),
                ),
                child: Center(
                  child: Text(
                    tab,
                    style: TextStyle(
                      color: isSelected
                          ? colorScheme.onSecondary
                          : (unselectedLabelColor ??
                              colorScheme.onSurfaceVariant),
                      fontSize: 14,
                      fontWeight:
                          isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _handleTap(int index) {
    HapticFeedback.lightImpact();
    onTap?.call(index);
    controller?.animateTo(index);
  }

  @override
  Size get preferredSize {
    switch (variant) {
      case CustomTabBarVariant.pills:
        return const Size.fromHeight(48);
      case CustomTabBarVariant.segmented:
        return const Size.fromHeight(80); // Including margin
      case CustomTabBarVariant.underline:
      case CustomTabBarVariant.standard:
      default:
        return const Size.fromHeight(kToolbarHeight);
    }
  }
}
