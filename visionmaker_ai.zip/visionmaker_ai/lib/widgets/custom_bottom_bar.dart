import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum CustomBottomBarVariant {
  standard,
  floating,
  minimal,
}

class CustomBottomBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int>? onTap;
  final CustomBottomBarVariant variant;
  final double? elevation;
  final Color? backgroundColor;
  final Color? selectedItemColor;
  final Color? unselectedItemColor;

  const CustomBottomBar({
    super.key,
    required this.currentIndex,
    this.onTap,
    this.variant = CustomBottomBarVariant.standard,
    this.elevation,
    this.backgroundColor,
    this.selectedItemColor,
    this.unselectedItemColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final items = _getBottomNavigationItems();

    switch (variant) {
      case CustomBottomBarVariant.floating:
        return _buildFloatingBottomBar(context, colorScheme, items);
      case CustomBottomBarVariant.minimal:
        return _buildMinimalBottomBar(context, colorScheme, items);
      case CustomBottomBarVariant.standard:
      default:
        return _buildStandardBottomBar(context, colorScheme, items);
    }
  }

  Widget _buildStandardBottomBar(
    BuildContext context,
    ColorScheme colorScheme,
    List<BottomNavigationBarItem> items,
  ) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: _handleTap,
      items: items,
      type: BottomNavigationBarType.fixed,
      elevation: elevation ?? 8,
      backgroundColor: backgroundColor ?? colorScheme.surface,
      selectedItemColor: selectedItemColor ?? colorScheme.secondary,
      unselectedItemColor: unselectedItemColor ?? colorScheme.onSurfaceVariant,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      selectedFontSize: 12,
      unselectedFontSize: 12,
    );
  }

  Widget _buildFloatingBottomBar(
    BuildContext context,
    ColorScheme colorScheme,
    List<BottomNavigationBarItem> items,
  ) {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: backgroundColor ?? colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withAlpha(26),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BottomNavigationBar(
          currentIndex: currentIndex,
          onTap: _handleTap,
          items: items,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          backgroundColor: Colors.transparent,
          selectedItemColor: selectedItemColor ?? colorScheme.secondary,
          unselectedItemColor:
              unselectedItemColor ?? colorScheme.onSurfaceVariant,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          selectedFontSize: 12,
          unselectedFontSize: 12,
        ),
      ),
    );
  }

  Widget _buildMinimalBottomBar(
    BuildContext context,
    ColorScheme colorScheme,
    List<BottomNavigationBarItem> items,
  ) {
    return Container(
      height: 80,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      decoration: BoxDecoration(
        color: backgroundColor ?? colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: colorScheme.outline.withAlpha(51),
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: items.asMap().entries.map((entry) {
          final index = entry.key;
          final item = entry.value;
          final isSelected = index == currentIndex;

          return GestureDetector(
            onTap: () => _handleTap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: isSelected
                    ? (selectedItemColor ?? colorScheme.secondary).withAlpha(26)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    (item.icon as Icon).icon,
                    color: isSelected
                        ? (selectedItemColor ?? colorScheme.secondary)
                        : (unselectedItemColor ?? colorScheme.onSurfaceVariant),
                    size: 24,
                  ),
                  if (isSelected && item.label != null) ...[
                    const SizedBox(width: 8),
                    Text(
                      item.label!,
                      style: TextStyle(
                        color: selectedItemColor ?? colorScheme.secondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _handleTap(int index) {
    HapticFeedback.lightImpact();
    onTap?.call(index);
    _navigateToRoute(index);
  }

  void _navigateToRoute(int index) {
    final routes = [
      '/video-creation-screen',
      '/video-history-screen',
      '/subscription-screen',
    ];

    if (index < routes.length) {
      // Note: This would typically be handled by the parent widget
      // but including for completeness based on requirements
    }
  }

  List<BottomNavigationBarItem> _getBottomNavigationItems() {
    return const [
      BottomNavigationBarItem(
        icon: Icon(Icons.video_call_outlined),
        activeIcon: Icon(Icons.video_call),
        label: 'Create',
        tooltip: 'Create Video',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.history_outlined),
        activeIcon: Icon(Icons.history),
        label: 'History',
        tooltip: 'Video History',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.workspace_premium_outlined),
        activeIcon: Icon(Icons.workspace_premium),
        label: 'Premium',
        tooltip: 'Subscription',
      ),
    ];
  }
}