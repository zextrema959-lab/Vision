import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum CustomAppBarVariant {
  primary,
  transparent,
  minimal,
  withActions,
}

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final Widget? titleWidget;
  final List<Widget>? actions;
  final Widget? leading;
  final bool automaticallyImplyLeading;
  final CustomAppBarVariant variant;
  final bool centerTitle;
  final double? elevation;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final VoidCallback? onBackPressed;
  final bool showBackButton;

  const CustomAppBar({
    super.key,
    this.title,
    this.titleWidget,
    this.actions,
    this.leading,
    this.automaticallyImplyLeading = true,
    this.variant = CustomAppBarVariant.primary,
    this.centerTitle = true,
    this.elevation,
    this.backgroundColor,
    this.foregroundColor,
    this.onBackPressed,
    this.showBackButton = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return AppBar(
      title: titleWidget ?? (title != null ? Text(title!) : null),
      actions: _buildActions(context),
      leading: _buildLeading(context),
      automaticallyImplyLeading: automaticallyImplyLeading && showBackButton,
      centerTitle: centerTitle,
      elevation: _getElevation(),
      backgroundColor: _getBackgroundColor(colorScheme),
      foregroundColor: _getForegroundColor(colorScheme),
      surfaceTintColor: Colors.transparent,
      systemOverlayStyle: _getSystemOverlayStyle(context),
      titleTextStyle: theme.appBarTheme.titleTextStyle?.copyWith(
        color: _getForegroundColor(colorScheme),
      ),
      iconTheme: IconThemeData(
        color: _getForegroundColor(colorScheme),
        size: 24,
      ),
      actionsIconTheme: IconThemeData(
        color: _getForegroundColor(colorScheme),
        size: 24,
      ),
    );
  }

  Widget? _buildLeading(BuildContext context) {
    if (leading != null) return leading;

    if (!showBackButton || !automaticallyImplyLeading) return null;

    final canPop = Navigator.of(context).canPop();
    if (!canPop) return null;

    return IconButton(
      icon: const Icon(Icons.arrow_back_ios_new),
      onPressed: () {
        HapticFeedback.lightImpact();
        if (onBackPressed != null) {
          onBackPressed!();
        } else {
          Navigator.of(context).pop();
        }
      },
      tooltip: 'Back',
    );
  }

  List<Widget>? _buildActions(BuildContext context) {
    if (actions == null) return null;

    return actions!.map((action) {
      if (action is IconButton) {
        return IconButton(
          icon: action.icon,
          onPressed: () {
            HapticFeedback.lightImpact();
            action.onPressed?.call();
          },
          tooltip: action.tooltip,
        );
      }
      return action;
    }).toList();
  }

  double _getElevation() {
    if (elevation != null) return elevation!;

    switch (variant) {
      case CustomAppBarVariant.primary:
        return 0;
      case CustomAppBarVariant.transparent:
        return 0;
      case CustomAppBarVariant.minimal:
        return 0;
      case CustomAppBarVariant.withActions:
        return 0;
    }
  }

  Color? _getBackgroundColor(ColorScheme colorScheme) {
    if (backgroundColor != null) return backgroundColor;

    switch (variant) {
      case CustomAppBarVariant.primary:
        return colorScheme.surface;
      case CustomAppBarVariant.transparent:
        return Colors.transparent;
      case CustomAppBarVariant.minimal:
        return colorScheme.surface;
      case CustomAppBarVariant.withActions:
        return colorScheme.surface;
    }
  }

  Color? _getForegroundColor(ColorScheme colorScheme) {
    if (foregroundColor != null) return foregroundColor;

    switch (variant) {
      case CustomAppBarVariant.primary:
        return colorScheme.onSurface;
      case CustomAppBarVariant.transparent:
        return colorScheme.onSurface;
      case CustomAppBarVariant.minimal:
        return colorScheme.onSurface;
      case CustomAppBarVariant.withActions:
        return colorScheme.onSurface;
    }
  }

  SystemUiOverlayStyle _getSystemOverlayStyle(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    switch (variant) {
      case CustomAppBarVariant.transparent:
        return brightness == Brightness.light
            ? SystemUiOverlayStyle.dark
            : SystemUiOverlayStyle.light;
      default:
        return brightness == Brightness.light
            ? SystemUiOverlayStyle.dark
            : SystemUiOverlayStyle.light;
    }
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
