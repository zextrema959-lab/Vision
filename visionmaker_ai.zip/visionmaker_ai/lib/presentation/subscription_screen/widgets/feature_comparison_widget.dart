import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class FeatureComparisonWidget extends StatelessWidget {
  const FeatureComparisonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final List<Map<String, dynamic>> comparisonData = [
      {
        "feature": "Generaciones por día",
        "free": "3",
        "premium": "Ilimitadas",
      },
      {
        "feature": "Calidad de video",
        "free": "720p",
        "premium": "4K HD",
      },
      {
        "feature": "Marca de agua",
        "free": "Sí",
        "premium": "Sin marca",
      },
      {
        "feature": "Procesamiento prioritario",
        "free": "Estándar",
        "premium": "Rápido",
      },
      {
        "feature": "Formatos de exportación",
        "free": "MP4",
        "premium": "MP4, MOV, GIF",
      },
      {
        "feature": "Duración máxima",
        "free": "15 segundos",
        "premium": "60 segundos",
      },
    ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Text(
              'Comparación de características',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                fontSize: 18.sp,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: DataTable(
              headingRowColor: WidgetStateProperty.all(
                colorScheme.secondary.withValues(alpha: 0.1),
              ),
              headingTextStyle: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                fontSize: 14.sp,
              ),
              dataTextStyle: theme.textTheme.bodyMedium?.copyWith(
                fontSize: 13.sp,
              ),
              columns: const [
                DataColumn(label: Text('Característica')),
                DataColumn(label: Text('Gratis')),
                DataColumn(label: Text('Premium')),
              ],
              rows: comparisonData.map((data) {
                return DataRow(
                  cells: [
                    DataCell(
                      SizedBox(
                        width: 40.w,
                        child: Text(
                          data["feature"] as String,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w500,
                            fontSize: 13.sp,
                          ),
                        ),
                      ),
                    ),
                    DataCell(
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: AppTheme.errorLight.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          data["free"] as String,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.errorLight,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.sp,
                          ),
                        ),
                      ),
                    ),
                    DataCell(
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: AppTheme.successLight.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          data["premium"] as String,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.successLight,
                            fontWeight: FontWeight.w500,
                            fontSize: 12.sp,
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }
}
