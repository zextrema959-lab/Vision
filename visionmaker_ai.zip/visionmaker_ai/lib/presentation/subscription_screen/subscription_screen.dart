import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/feature_comparison_widget.dart';
import './widgets/hero_section_widget.dart';
import './widgets/subscription_card_widget.dart';
import './widgets/usage_stats_widget.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  int selectedPlanIndex = 1; // Annual plan selected by default
  bool isProcessingPayment = false;
  bool showTrialOffer = true;

  final List<Map<String, dynamic>> subscriptionPlans = [
    {
      "title": "Plan Mensual",
      "price": "€9,99",
      "billingCycle": "/mes",
      "originalPrice": null,
      "savingsText": null,
      "isPopular": false,
      "features": [
        "Generaciones ilimitadas",
        "Videos en calidad 4K HD",
        "Sin marca de agua",
        "Procesamiento prioritario",
        "Todos los formatos de exportación",
        "Videos hasta 60 segundos",
        "Soporte técnico premium",
      ],
    },
    {
      "title": "Plan Anual",
      "price": "€79,99",
      "billingCycle": "/año",
      "originalPrice": "€119,88",
      "savingsText": "Ahorra 33% - ¡2 meses gratis!",
      "isPopular": true,
      "features": [
        "Generaciones ilimitadas",
        "Videos en calidad 4K HD",
        "Sin marca de agua",
        "Procesamiento prioritario",
        "Todos los formatos de exportación",
        "Videos hasta 60 segundos",
        "Soporte técnico premium",
        "Acceso anticipado a nuevas funciones",
        "Plantillas exclusivas premium",
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'close',
            color: colorScheme.onSurface,
            size: 24,
          ),
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).pop();
          },
        ),
        title: Text(
          'VisionMaker Pro',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w700,
            fontSize: 18.sp,
          ),
        ),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              _showRestorePurchases();
            },
            child: Text(
              'Restaurar',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.secondary,
                fontWeight: FontWeight.w600,
                fontSize: 13.sp,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const HeroSectionWidget(),
            const UsageStatsWidget(),
            SizedBox(height: 2.h),
            if (showTrialOffer) _buildTrialOffer(),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Text(
                'Elige tu plan',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  fontSize: 20.sp,
                ),
              ),
            ),
            SizedBox(height: 2.h),
            ...subscriptionPlans.asMap().entries.map((entry) {
              final index = entry.key;
              final plan = entry.value;

              return SubscriptionCardWidget(
                title: plan["title"] as String,
                price: plan["price"] as String,
                billingCycle: plan["billingCycle"] as String,
                originalPrice: plan["originalPrice"] as String?,
                savingsText: plan["savingsText"] as String?,
                features: (plan["features"] as List).cast<String>(),
                isPopular: plan["isPopular"] as bool,
                isSelected: selectedPlanIndex == index,
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() {
                    selectedPlanIndex = index;
                  });
                },
              );
            }),
            SizedBox(height: 3.h),
            _buildUpgradeButton(),
            SizedBox(height: 2.h),
            const FeatureComparisonWidget(),
            SizedBox(height: 3.h),
            _buildLegalInfo(),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _buildTrialOffer() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.accentLight,
            AppTheme.accentLight.withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.accentLight.withValues(alpha: 0.3),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 12.w,
            height: 12.w,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: CustomIconWidget(
              iconName: 'star',
              color: Colors.white,
              size: 24,
            ),
          ),
          SizedBox(width: 4.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '🎉 Prueba gratuita de 7 días',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 16.sp,
                  ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  'Cancela cuando quieras. Sin compromisos.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: Colors.white.withValues(alpha: 0.9),
                    fontSize: 12.sp,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                showTrialOffer = false;
              });
            },
            child: CustomIconWidget(
              iconName: 'close',
              color: Colors.white.withValues(alpha: 0.7),
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUpgradeButton() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final selectedPlan = subscriptionPlans[selectedPlanIndex];

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: ElevatedButton(
        onPressed: isProcessingPayment ? null : _handleUpgrade,
        style: ElevatedButton.styleFrom(
          backgroundColor: colorScheme.secondary,
          foregroundColor: Colors.white,
          padding: EdgeInsets.symmetric(vertical: 2.h),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 4,
          shadowColor: colorScheme.secondary.withValues(alpha: 0.3),
        ),
        child: isProcessingPayment
            ? SizedBox(
                height: 24,
                width: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'security',
                    color: Colors.white,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    showTrialOffer
                        ? 'Comenzar prueba gratuita'
                        : 'Actualizar a ${selectedPlan["title"]}',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 16.sp,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildLegalInfo() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        children: [
          Text(
            'Pago seguro con cifrado de extremo a extremo',
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
              fontSize: 11.sp,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: AppTheme.successLight,
                size: 16,
              ),
              SizedBox(width: 1.w),
              Text(
                'Cancela en cualquier momento',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.successLight,
                  fontWeight: FontWeight.w600,
                  fontSize: 12.sp,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Wrap(
            alignment: WrapAlignment.center,
            children: [
              _buildLegalLink('Términos de servicio'),
              Text(
                ' • ',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontSize: 11.sp,
                ),
              ),
              _buildLegalLink('Política de privacidad'),
              Text(
                ' • ',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                  fontSize: 11.sp,
                ),
              ),
              _buildLegalLink('Política de reembolso'),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            'La suscripción se renueva automáticamente. Puedes cancelar en cualquier momento desde la configuración de tu cuenta.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
              fontSize: 10.sp,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildLegalLink(String text) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        _showLegalDocument(text);
      },
      child: Text(
        text,
        style: theme.textTheme.bodySmall?.copyWith(
          color: colorScheme.secondary,
          fontSize: 11.sp,
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }

  Future<void> _handleUpgrade() async {
    setState(() {
      isProcessingPayment = true;
    });

    HapticFeedback.mediumImpact();

    try {
      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        _showErrorDialog();
      }
    } finally {
      if (mounted) {
        setState(() {
          isProcessingPayment = false;
        });
      }
    }
  }

  void _showSuccessDialog() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 20.w,
              height: 20.w,
              decoration: BoxDecoration(
                color: AppTheme.successLight,
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'check',
                color: Colors.white,
                size: 40,
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              '¡Bienvenido a VisionMaker Pro!',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                fontSize: 18.sp,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Tu suscripción está activa. Disfruta de todas las funciones premium.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
                fontSize: 14.sp,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 3.h),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  Navigator.pushNamed(context, '/video-creation-screen');
                },
                child: Text(
                  'Comenzar a crear',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showErrorDialog() {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'error_outline',
              color: AppTheme.errorLight,
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Error en el pago',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        content: Text(
          'No se pudo procesar tu pago. Por favor, verifica tu método de pago e inténtalo de nuevo.',
          style: theme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              'Entendido',
              style: TextStyle(color: colorScheme.secondary),
            ),
          ),
        ],
      ),
    );
  }

  void _showRestorePurchases() {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Restaurar compras',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'No se encontraron compras anteriores asociadas a esta cuenta.',
          style: theme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  void _showLegalDocument(String title) {
    final theme = Theme.of(context);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.9,
        minChildSize: 0.5,
        builder: (context, scrollController) => Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            children: [
              Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: theme.colorScheme.outline.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                title,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 2.h),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: Text(
                    _getLegalContent(title),
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getLegalContent(String title) {
    switch (title) {
      case 'Términos de servicio':
        return '''Al utilizar VisionMaker AI, aceptas estos términos de servicio. La aplicación proporciona servicios de generación de video mediante inteligencia artificial.

1. Uso del servicio
- Debes tener al menos 18 años para usar este servicio
- No puedes usar el servicio para contenido ilegal o dañino
- Respetas los derechos de propiedad intelectual

2. Suscripciones
- Las suscripciones se renuevan automáticamente
- Puedes cancelar en cualquier momento
- Los reembolsos se procesan según nuestra política

3. Limitaciones
- No garantizamos disponibilidad del 100%
- Nos reservamos el derecho de modificar el servicio

Última actualización: 19 de agosto de 2025''';

      case 'Política de privacidad':
        return '''Tu privacidad es importante para nosotros. Esta política explica cómo recopilamos y usamos tu información.

1. Información que recopilamos
- Información de cuenta (email, nombre)
- Datos de uso de la aplicación
- Información de pago (procesada por terceros)

2. Cómo usamos tu información
- Para proporcionar y mejorar nuestros servicios
- Para procesar pagos y suscripciones
- Para comunicarnos contigo sobre el servicio

3. Compartir información
- No vendemos tu información personal
- Compartimos datos solo cuando es necesario para el servicio
- Cumplimos con las regulaciones de protección de datos

4. Tus derechos
- Puedes acceder a tu información
- Puedes solicitar la eliminación de tus datos
- Puedes optar por no recibir comunicaciones

Última actualización: 19 de agosto de 2025''';

      case 'Política de reembolso':
        return '''Nuestra política de reembolso está diseñada para ser justa y transparente.

1. Prueba gratuita
- Puedes cancelar durante la prueba sin cargos
- La cancelación debe realizarse antes del final del período de prueba

2. Reembolsos de suscripción
- Reembolsos disponibles dentro de 14 días de la compra
- Debe solicitarse a través del soporte al cliente
- Se procesan a través del método de pago original

3. Excepciones
- No se reembolsan suscripciones parcialmente utilizadas después de 14 días
- Violaciones de términos de servicio anulan el derecho a reembolso

4. Proceso de reembolso
- Contacta a soporte@visionmaker.ai
- Proporciona detalles de la transacción
- Los reembolsos se procesan en 5-10 días hábiles

Última actualización: 19 de agosto de 2025''';

      default:
        return 'Contenido no disponible.';
    }
  }
}
