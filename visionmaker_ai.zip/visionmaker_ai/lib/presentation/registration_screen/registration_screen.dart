import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/email_availability_indicator.dart';
import './widgets/password_strength_indicator.dart';
import './widgets/social_signup_button.dart';
import './widgets/terms_checkbox.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _emailFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();
  final _confirmPasswordFocusNode = FocusNode();

  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _isEmailAvailable = false;
  bool _isTermsAccepted = false;
  bool _isLoading = false;
  bool _isGoogleLoading = false;
  String _emailError = '';
  String _passwordError = '';
  String _confirmPasswordError = '';

  final List<Map<String, dynamic>> _mockUsers = [
    {
      "email": "admin@visionmaker.com",
      "password": "Admin123!",
      "name": "Administrador VisionMaker"
    },
    {
      "email": "test@gmail.com",
      "password": "Test123!",
      "name": "Usuario de Prueba"
    },
    {
      "email": "user@hotmail.com",
      "password": "User123!",
      "name": "Usuario Demo"
    }
  ];

  @override
  void initState() {
    super.initState();
    _emailController.addListener(_validateEmail);
    _passwordController.addListener(_validatePassword);
    _confirmPasswordController.addListener(_validateConfirmPassword);
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    _confirmPasswordFocusNode.dispose();
    super.dispose();
  }

  void _validateEmail() {
    final email = _emailController.text;
    setState(() {
      if (email.isEmpty) {
        _emailError = '';
      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email)) {
        _emailError = 'Formato de email inválido';
      } else {
        _emailError = '';
      }
    });
  }

  void _validatePassword() {
    final password = _passwordController.text;
    setState(() {
      if (password.isEmpty) {
        _passwordError = '';
      } else if (password.length < 8) {
        _passwordError = 'La contraseña debe tener al menos 8 caracteres';
      } else {
        _passwordError = '';
      }
    });
  }

  void _validateConfirmPassword() {
    final confirmPassword = _confirmPasswordController.text;
    setState(() {
      if (confirmPassword.isEmpty) {
        _confirmPasswordError = '';
      } else if (confirmPassword != _passwordController.text) {
        _confirmPasswordError = 'Las contraseñas no coinciden';
      } else {
        _confirmPasswordError = '';
      }
    });
  }

  bool get _isFormValid {
    return _emailController.text.isNotEmpty &&
        _passwordController.text.isNotEmpty &&
        _confirmPasswordController.text.isNotEmpty &&
        _isEmailAvailable &&
        _emailError.isEmpty &&
        _passwordError.isEmpty &&
        _confirmPasswordError.isEmpty &&
        _isTermsAccepted;
  }

  Future<void> _handleRegistration() async {
    if (!_isFormValid) return;

    setState(() => _isLoading = true);

    try {
      // Simulate registration API call
      await Future.delayed(const Duration(seconds: 2));

      // Check if email already exists
      final existingUser = _mockUsers.any((user) =>
          user['email'].toLowerCase() == _emailController.text.toLowerCase());

      if (existingUser) {
        _showErrorSnackBar('Este email ya está registrado');
        return;
      }

      // Show success message
      _showSuccessDialog();
    } catch (e) {
      _showErrorSnackBar('Error al crear la cuenta. Inténtalo de nuevo.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _handleGoogleSignup() async {
    setState(() => _isGoogleLoading = true);

    try {
      // Simulate Google OAuth flow
      await Future.delayed(const Duration(seconds: 2));

      // Mock successful Google signup
      _showSuccessDialog();
    } catch (e) {
      _showErrorSnackBar('Error al conectar con Google. Inténtalo de nuevo.');
    } finally {
      setState(() => _isGoogleLoading = false);
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: const Color(0xFF10B981),
              size: 6.w,
            ),
            SizedBox(width: 3.w),
            Text(
              '¡Bienvenido!',
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
        content: Text(
          'Tu cuenta ha sido creada exitosamente. Ahora puedes comenzar a crear videos increíbles con IA.',
          style: TextStyle(
            fontSize: 12.sp,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            height: 1.4,
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/subscription-screen');
            },
            child: const Text('Continuar'),
          ),
        ],
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  void _openTermsOfService() {
    // In a real app, this would open an in-app browser
    _showInfoDialog(
      'Términos de Servicio',
      'Aquí se mostrarían los términos de servicio completos de VisionMaker AI.',
    );
  }

  void _openPrivacyPolicy() {
    // In a real app, this would open an in-app browser
    _showInfoDialog(
      'Política de Privacidad',
      'Aquí se mostraría la política de privacidad completa de VisionMaker AI.',
    );
  }

  void _showInfoDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        content: Text(
          content,
          style: TextStyle(
            fontSize: 12.sp,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            height: 1.4,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back_ios',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 6.w,
          ),
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
          },
        ),
        systemOverlayStyle: SystemUiOverlayStyle.dark,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 6.w),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 2.h),
                _buildHeader(),
                SizedBox(height: 6.h),
                _buildEmailField(),
                SizedBox(height: 4.h),
                _buildPasswordField(),
                SizedBox(height: 4.h),
                _buildConfirmPasswordField(),
                SizedBox(height: 4.h),
                _buildTermsCheckbox(),
                SizedBox(height: 6.h),
                _buildCreateAccountButton(),
                SizedBox(height: 4.h),
                _buildDivider(),
                SizedBox(height: 4.h),
                _buildGoogleSignupButton(),
                SizedBox(height: 4.h),
                _buildLoginLink(),
                SizedBox(height: 4.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Crear Cuenta',
          style: TextStyle(
            fontSize: 24.sp,
            fontWeight: FontWeight.w700,
            color: AppTheme.lightTheme.colorScheme.onSurface,
            letterSpacing: -0.02,
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          'Únete a VisionMaker AI y comienza a crear videos virales con inteligencia artificial',
          style: TextStyle(
            fontSize: 14.sp,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            height: 1.4,
          ),
        ),
      ],
    );
  }

  Widget _buildEmailField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Email',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _emailController,
          focusNode: _emailFocusNode,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.next,
          onFieldSubmitted: (_) => _passwordFocusNode.requestFocus(),
          decoration: InputDecoration(
            hintText: 'tu@email.com',
            prefixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: 'email',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
            ),
            suffixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: EmailAvailabilityIndicator(
                email: _emailController.text,
                onAvailabilityChanged: (isAvailable) {
                  setState(() => _isEmailAvailable = isAvailable);
                },
              ),
            ),
            errorText: _emailError.isNotEmpty ? _emailError : null,
          ),
        ),
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Contraseña',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _passwordController,
          focusNode: _passwordFocusNode,
          obscureText: !_isPasswordVisible,
          textInputAction: TextInputAction.next,
          onFieldSubmitted: (_) => _confirmPasswordFocusNode.requestFocus(),
          decoration: InputDecoration(
            hintText: 'Ingresa tu contraseña',
            prefixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: 'lock',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
            ),
            suffixIcon: IconButton(
              icon: CustomIconWidget(
                iconName: _isPasswordVisible ? 'visibility_off' : 'visibility',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
              onPressed: () {
                HapticFeedback.lightImpact();
                setState(() => _isPasswordVisible = !_isPasswordVisible);
              },
            ),
            errorText: _passwordError.isNotEmpty ? _passwordError : null,
          ),
        ),
        PasswordStrengthIndicator(password: _passwordController.text),
      ],
    );
  }

  Widget _buildConfirmPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Confirmar Contraseña',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 1.h),
        TextFormField(
          controller: _confirmPasswordController,
          focusNode: _confirmPasswordFocusNode,
          obscureText: !_isConfirmPasswordVisible,
          textInputAction: TextInputAction.done,
          decoration: InputDecoration(
            hintText: 'Confirma tu contraseña',
            prefixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: 'lock',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
            ),
            suffixIcon: IconButton(
              icon: CustomIconWidget(
                iconName:
                    _isConfirmPasswordVisible ? 'visibility_off' : 'visibility',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 5.w,
              ),
              onPressed: () {
                HapticFeedback.lightImpact();
                setState(() =>
                    _isConfirmPasswordVisible = !_isConfirmPasswordVisible);
              },
            ),
            errorText:
                _confirmPasswordError.isNotEmpty ? _confirmPasswordError : null,
          ),
        ),
      ],
    );
  }

  Widget _buildTermsCheckbox() {
    return TermsCheckbox(
      isChecked: _isTermsAccepted,
      onChanged: (value) {
        HapticFeedback.lightImpact();
        setState(() => _isTermsAccepted = value ?? false);
      },
      onTermsTap: _openTermsOfService,
      onPrivacyTap: _openPrivacyPolicy,
    );
  }

  Widget _buildCreateAccountButton() {
    return SizedBox(
      width: double.infinity,
      height: 12.h,
      child: ElevatedButton(
        onPressed: _isFormValid && !_isLoading ? _handleRegistration : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: _isFormValid
              ? AppTheme.lightTheme.colorScheme.secondary
              : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          foregroundColor: AppTheme.lightTheme.colorScheme.onSecondary,
          elevation: _isFormValid ? 2 : 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: _isLoading
            ? SizedBox(
                width: 5.w,
                height: 5.w,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppTheme.lightTheme.colorScheme.onSecondary,
                  ),
                ),
              )
            : Text(
                'Crear Cuenta',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  letterSpacing: -0.02,
                ),
              ),
      ),
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        Expanded(
          child: Divider(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
            thickness: 1,
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w),
          child: Text(
            'o',
            style: TextStyle(
              fontSize: 12.sp,
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Expanded(
          child: Divider(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
            thickness: 1,
          ),
        ),
      ],
    );
  }

  Widget _buildGoogleSignupButton() {
    return SocialSignupButton(
      onPressed: _handleGoogleSignup,
      isLoading: _isGoogleLoading,
    );
  }

  Widget _buildLoginLink() {
    return Center(
      child: RichText(
        text: TextSpan(
          style: TextStyle(
            fontSize: 12.sp,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
          children: [
            const TextSpan(text: '¿Ya tienes una cuenta? '),
            WidgetSpan(
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  Navigator.pushReplacementNamed(context, '/login-screen');
                },
                child: Text(
                  'Iniciar Sesión',
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
