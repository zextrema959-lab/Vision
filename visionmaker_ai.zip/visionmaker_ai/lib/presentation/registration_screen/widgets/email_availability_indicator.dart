import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum EmailAvailabilityStatus { idle, checking, available, unavailable, invalid }

class EmailAvailabilityIndicator extends StatefulWidget {
  final String email;
  final Function(bool) onAvailabilityChanged;

  const EmailAvailabilityIndicator({
    super.key,
    required this.email,
    required this.onAvailabilityChanged,
  });

  @override
  State<EmailAvailabilityIndicator> createState() =>
      _EmailAvailabilityIndicatorState();
}

class _EmailAvailabilityIndicatorState
    extends State<EmailAvailabilityIndicator> {
  EmailAvailabilityStatus _status = EmailAvailabilityStatus.idle;
  String _lastCheckedEmail = '';

  @override
  void didUpdateWidget(EmailAvailabilityIndicator oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.email != oldWidget.email) {
      _checkEmailAvailability();
    }
  }

  void _checkEmailAvailability() async {
    if (widget.email.isEmpty || widget.email == _lastCheckedEmail) {
      return;
    }

    if (!_isValidEmail(widget.email)) {
      setState(() {
        _status = EmailAvailabilityStatus.invalid;
      });
      widget.onAvailabilityChanged(false);
      return;
    }

    setState(() {
      _status = EmailAvailabilityStatus.checking;
    });

    _lastCheckedEmail = widget.email;

    // Simulate API call delay
    await Future.delayed(const Duration(milliseconds: 800));

    if (_lastCheckedEmail != widget.email) return;

    // Mock email availability check
    final unavailableEmails = [
      'admin@visionmaker.com',
      'test@gmail.com',
      'user@hotmail.com',
      'demo@yahoo.com',
    ];

    final isAvailable = !unavailableEmails.contains(widget.email.toLowerCase());

    setState(() {
      _status = isAvailable
          ? EmailAvailabilityStatus.available
          : EmailAvailabilityStatus.unavailable;
    });

    widget.onAvailabilityChanged(isAvailable);
  }

  bool _isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: _buildIndicator(),
    );
  }

  Widget _buildIndicator() {
    switch (_status) {
      case EmailAvailabilityStatus.checking:
        return SizedBox(
          width: 5.w,
          height: 5.w,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(
              AppTheme.lightTheme.colorScheme.secondary,
            ),
          ),
        );
      case EmailAvailabilityStatus.available:
        return CustomIconWidget(
          iconName: 'check_circle',
          color: const Color(0xFF10B981),
          size: 5.w,
        );
      case EmailAvailabilityStatus.unavailable:
        return CustomIconWidget(
          iconName: 'cancel',
          color: AppTheme.lightTheme.colorScheme.error,
          size: 5.w,
        );
      case EmailAvailabilityStatus.invalid:
        return CustomIconWidget(
          iconName: 'error',
          color: AppTheme.lightTheme.colorScheme.error,
          size: 5.w,
        );
      case EmailAvailabilityStatus.idle:
      default:
        return SizedBox(width: 5.w);
    }
  }
}
