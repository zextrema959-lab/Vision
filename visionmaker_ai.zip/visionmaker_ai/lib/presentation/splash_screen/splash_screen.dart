import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoAnimationController;
  late AnimationController _loadingAnimationController;
  late Animation<double> _logoFadeAnimation;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _loadingOpacityAnimation;

  bool _isInitializing = true;
  bool _hasError = false;
  String _statusMessage = 'Inicializando VisionMaker AI...';

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initializeApp();
  }

  void _setupAnimations() {
    // Logo animation controller
    _logoAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    // Loading animation controller
    _loadingAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..repeat(reverse: true);

    // Logo fade animation
    _logoFadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: const Interval(0.0, 0.8, curve: Curves.easeOut),
    ));

    // Logo scale animation
    _logoScaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _logoAnimationController,
      curve: const Interval(0.2, 1.0, curve: Curves.elasticOut),
    ));

    // Loading opacity animation
    _loadingOpacityAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _loadingAnimationController,
      curve: Curves.easeInOut,
    ));

    // Start logo animation
    _logoAnimationController.forward();
  }

  Future<void> _initializeApp() async {
    try {
      // Simulate initialization tasks
      await Future.wait([
        _checkAuthenticationStatus(),
        _loadUserPreferences(),
        _verifySubscriptionStatus(),
        _prepareCachedVideoHistory(),
        _initializeAIServices(),
      ]);

      // Minimum splash display time
      await Future.delayed(const Duration(milliseconds: 2500));

      if (mounted) {
        _navigateToNextScreen();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _hasError = true;
          _statusMessage = 'Error de conexión. Toca para reintentar.';
        });
      }
    }
  }

  Future<void> _checkAuthenticationStatus() async {
    setState(() {
      _statusMessage = 'Verificando autenticación...';
    });

    // Simulate auth check
    await Future.delayed(const Duration(milliseconds: 500));
  }

  Future<void> _loadUserPreferences() async {
    setState(() {
      _statusMessage = 'Cargando preferencias...';
    });

    // Simulate preferences loading
    await Future.delayed(const Duration(milliseconds: 400));
  }

  Future<void> _verifySubscriptionStatus() async {
    setState(() {
      _statusMessage = 'Verificando suscripción...';
    });

    // Simulate subscription check
    await Future.delayed(const Duration(milliseconds: 300));
  }

  Future<void> _prepareCachedVideoHistory() async {
    setState(() {
      _statusMessage = 'Preparando historial de videos...';
    });

    // Simulate video history preparation
    await Future.delayed(const Duration(milliseconds: 600));
  }

  Future<void> _initializeAIServices() async {
    setState(() {
      _statusMessage = 'Conectando servicios de IA...';
    });

    // Simulate AI services initialization
    await Future.delayed(const Duration(milliseconds: 700));
  }

  void _navigateToNextScreen() {
    // Navigation logic based on user status
    // For demo purposes, navigate to video creation screen
    Navigator.pushReplacementNamed(context, '/video-creation-screen');
  }

  void _retryInitialization() {
    setState(() {
      _hasError = false;
      _isInitializing = true;
      _statusMessage = 'Reintentando conexión...';
    });

    _initializeApp();
  }

  @override
  void dispose() {
    _logoAnimationController.dispose();
    _loadingAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: AppTheme.primaryDark,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: AppTheme.primaryDark,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppTheme.primaryDark,
                AppTheme.primaryDark.withValues(alpha: 0.8),
                AppTheme.secondaryDark.withValues(alpha: 0.3),
              ],
              stops: const [0.0, 0.7, 1.0],
            ),
          ),
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo section
                Expanded(
                  flex: 3,
                  child: Center(
                    child: AnimatedBuilder(
                      animation: _logoAnimationController,
                      builder: (context, child) {
                        return FadeTransition(
                          opacity: _logoFadeAnimation,
                          child: ScaleTransition(
                            scale: _logoScaleAnimation,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // App logo
                                Container(
                                  width: 25.w,
                                  height: 25.w,
                                  decoration: BoxDecoration(
                                    color: AppTheme.secondaryLight,
                                    borderRadius: BorderRadius.circular(6.w),
                                    boxShadow: [
                                      BoxShadow(
                                        color: AppTheme.secondaryLight
                                            .withValues(alpha: 0.3),
                                        blurRadius: 20,
                                        spreadRadius: 2,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: CustomIconWidget(
                                      iconName: 'video_call',
                                      color: AppTheme.surfaceLight,
                                      size: 12.w,
                                    ),
                                  ),
                                ),
                                SizedBox(height: 4.h),
                                // App name
                                Text(
                                  'VisionMaker AI',
                                  style: AppTheme
                                      .lightTheme.textTheme.headlineMedium
                                      ?.copyWith(
                                    color: AppTheme.textPrimaryDark,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: -0.5,
                                  ),
                                ),
                                SizedBox(height: 1.h),
                                // Tagline
                                Text(
                                  'Crea videos virales con IA',
                                  style: AppTheme.lightTheme.textTheme.bodyLarge
                                      ?.copyWith(
                                    color: AppTheme.textSecondaryDark,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                // Loading section
                Expanded(
                  flex: 1,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_hasError) ...[
                        // Error state
                        GestureDetector(
                          onTap: _retryInitialization,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 8.w,
                              vertical: 2.h,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.errorLight.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(3.w),
                              border: Border.all(
                                color:
                                    AppTheme.errorLight.withValues(alpha: 0.3),
                                width: 1,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CustomIconWidget(
                                  iconName: 'refresh',
                                  color: AppTheme.errorLight,
                                  size: 5.w,
                                ),
                                SizedBox(width: 2.w),
                                Flexible(
                                  child: Text(
                                    _statusMessage,
                                    style: AppTheme
                                        .lightTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color: AppTheme.errorLight,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ] else ...[
                        // Loading state
                        AnimatedBuilder(
                          animation: _loadingAnimationController,
                          builder: (context, child) {
                            return FadeTransition(
                              opacity: _loadingOpacityAnimation,
                              child: Column(
                                children: [
                                  // Loading indicator
                                  SizedBox(
                                    width: 8.w,
                                    height: 8.w,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 3,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        AppTheme.secondaryLight,
                                      ),
                                      backgroundColor: AppTheme.secondaryLight
                                          .withValues(alpha: 0.2),
                                    ),
                                  ),
                                  SizedBox(height: 3.h),
                                  // Status message
                                  Text(
                                    _statusMessage,
                                    style: AppTheme
                                        .lightTheme.textTheme.bodyMedium
                                        ?.copyWith(
                                      color: AppTheme.textSecondaryDark,
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ],
                  ),
                ),

                // Bottom section
                Padding(
                  padding: EdgeInsets.only(bottom: 4.h),
                  child: Column(
                    children: [
                      // Version info
                      Text(
                        'Versión 1.0.0',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.textSecondaryDark.withValues(alpha: 0.6),
                          fontSize: 10.sp,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      // Copyright
                      Text(
                        '© 2024 VisionMaker AI',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.textSecondaryDark.withValues(alpha: 0.6),
                          fontSize: 10.sp,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
