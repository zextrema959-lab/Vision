import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/generation_button_widget.dart';
import './widgets/image_to_video_widget.dart';
import './widgets/style_selector_widget.dart';
import './widgets/text_to_video_widget.dart';
import './widgets/video_settings_widget.dart';

class VideoCreationScreen extends StatefulWidget {
  const VideoCreationScreen({super.key});

  @override
  State<VideoCreationScreen> createState() => _VideoCreationScreenState();
}

class _VideoCreationScreenState extends State<VideoCreationScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;

  // Form state
  String _textPrompt = '';
  XFile? _selectedImage;
  String _selectedAspectRatio = '9:16';
  int _selectedDuration = 5;
  String _selectedQuality = 'Estándar';
  String _selectedStyle = 'cinematic';
  bool _isLoading = false;

  // User state (mock data)
  final bool _isPremium = false;
  final int _userCredits = 25;

  // Mock user data
  final Map<String, dynamic> _userData = {
    "id": 1,
    "name": "María García",
    "email": "maria.garcia@email.com",
    "isPremium": false,
    "credits": 25,
    "subscription": {
      "type": "free",
      "expiresAt": null,
    },
    "preferences": {
      "defaultAspectRatio": "9:16",
      "defaultQuality": "Estándar",
      "defaultStyle": "cinematic",
    }
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadUserPreferences();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadUserPreferences() {
    final preferences = _userData['preferences'] as Map<String, dynamic>;
    setState(() {
      _selectedAspectRatio = preferences['defaultAspectRatio'] ?? '9:16';
      _selectedQuality = preferences['defaultQuality'] ?? 'Estándar';
      _selectedStyle = preferences['defaultStyle'] ?? 'cinematic';
    });
  }

  bool _isFormValid() {
    if (_tabController.index == 0) {
      return _textPrompt.trim().isNotEmpty && _textPrompt.trim().length >= 10;
    } else {
      return _selectedImage != null;
    }
  }

  int _getEstimatedTime() {
    int baseTime = 2;

    // Add time based on duration
    baseTime += (_selectedDuration / 5).round();

    // Add time for HD quality
    if (_selectedQuality == 'HD') {
      baseTime += 1;
    }

    // Add time for complex styles
    if (_selectedStyle == 'artistic' || _selectedStyle == 'animated') {
      baseTime += 1;
    }

    return baseTime;
  }

  int _getCreditCost() {
    if (_isPremium) return 0;

    int baseCost = 5;

    // Add cost for longer duration
    if (_selectedDuration > 7) {
      baseCost += 2;
    }

    // Add cost for HD quality
    if (_selectedQuality == 'HD') {
      baseCost += 3;
    }

    return baseCost;
  }

  void _generateVideo() async {
    if (!_isFormValid()) return;

    HapticFeedback.mediumImpact();

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate video generation process
      await Future.delayed(const Duration(seconds: 2));

      // Show success message
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "Video enviado para generación. Te notificaremos cuando esté listo.",
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: Colors.white,
              ),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            duration: const Duration(seconds: 3),
          ),
        );

        // Navigate to history screen
        Navigator.pushReplacementNamed(context, '/video-history-screen');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "Error al generar el video. Inténtalo de nuevo.",
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: Colors.white,
              ),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _saveDraft() {
    HapticFeedback.lightImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "Borrador guardado exitosamente",
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: Colors.white,
          ),
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'close',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
          onPressed: () {
            HapticFeedback.lightImpact();
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Crear Video",
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: _saveDraft,
            child: Text(
              "Guardar",
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.secondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          SizedBox(width: 2.w),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(8.h),
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: TabBar(
              controller: _tabController,
              onTap: (index) {
                HapticFeedback.selectionClick();
                setState(() {});
              },
              tabs: [
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'text_fields',
                        color: _tabController.index == 0
                            ? AppTheme.lightTheme.colorScheme.secondary
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Text("Texto a Video"),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'image',
                        color: _tabController.index == 1
                            ? AppTheme.lightTheme.colorScheme.secondary
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        size: 20,
                      ),
                      SizedBox(width: 2.w),
                      Text("Imagen a Video"),
                    ],
                  ),
                ),
              ],
              indicatorColor: AppTheme.lightTheme.colorScheme.secondary,
              labelColor: AppTheme.lightTheme.colorScheme.secondary,
              unselectedLabelColor:
                  AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              indicatorSize: TabBarIndicatorSize.label,
              dividerColor: Colors.transparent,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // User credits info
          if (!_isPremium)
            Container(
              width: double.infinity,
              margin: EdgeInsets.all(4.w),
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.secondary
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.secondary
                      .withValues(alpha: 0.3),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'account_balance_wallet',
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    size: 20,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      "Tienes $_userCredits créditos disponibles",
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.secondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/subscription-screen');
                    },
                    child: Text(
                      "Obtener más",
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.secondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                SingleChildScrollView(
                  child: Column(
                    children: [
                      TextToVideoWidget(
                        currentText: _textPrompt,
                        onTextChanged: (text) {
                          setState(() {
                            _textPrompt = text;
                          });
                        },
                      ),
                      VideoSettingsWidget(
                        selectedAspectRatio: _selectedAspectRatio,
                        selectedDuration: _selectedDuration,
                        selectedQuality: _selectedQuality,
                        onAspectRatioChanged: (ratio) {
                          setState(() {
                            _selectedAspectRatio = ratio;
                          });
                        },
                        onDurationChanged: (duration) {
                          setState(() {
                            _selectedDuration = duration;
                          });
                        },
                        onQualityChanged: (quality) {
                          setState(() {
                            _selectedQuality = quality;
                          });
                        },
                        isPremium: _isPremium,
                      ),
                      StyleSelectorWidget(
                        selectedStyle: _selectedStyle,
                        onStyleChanged: (style) {
                          setState(() {
                            _selectedStyle = style;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                SingleChildScrollView(
                  child: Column(
                    children: [
                      ImageToVideoWidget(
                        selectedImage: _selectedImage,
                        onImageSelected: (image) {
                          setState(() {
                            _selectedImage = image;
                          });
                        },
                      ),
                      VideoSettingsWidget(
                        selectedAspectRatio: _selectedAspectRatio,
                        selectedDuration: _selectedDuration,
                        selectedQuality: _selectedQuality,
                        onAspectRatioChanged: (ratio) {
                          setState(() {
                            _selectedAspectRatio = ratio;
                          });
                        },
                        onDurationChanged: (duration) {
                          setState(() {
                            _selectedDuration = duration;
                          });
                        },
                        onQualityChanged: (quality) {
                          setState(() {
                            _selectedQuality = quality;
                          });
                        },
                        isPremium: _isPremium,
                      ),
                      StyleSelectorWidget(
                        selectedStyle: _selectedStyle,
                        onStyleChanged: (style) {
                          setState(() {
                            _selectedStyle = style;
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Generation button
          GenerationButtonWidget(
            isEnabled: _isFormValid(),
            isLoading: _isLoading,
            onPressed: _generateVideo,
            estimatedTime: _getEstimatedTime(),
            creditCost: _getCreditCost(),
            isPremium: _isPremium,
          ),
        ],
      ),
    );
  }
}
