import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/bulk_action_toolbar_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/filter_bottom_sheet_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/video_thumbnail_widget.dart';

class VideoHistoryScreen extends StatefulWidget {
  const VideoHistoryScreen({super.key});

  @override
  State<VideoHistoryScreen> createState() => _VideoHistoryScreenState();
}

class _VideoHistoryScreenState extends State<VideoHistoryScreen> {
  final ScrollController _scrollController = ScrollController();
  final List<Map<String, dynamic>> _selectedVideos = [];

  bool _isMultiSelectMode = false;
  bool _isLoading = false;
  bool _hasMoreVideos = true;
  String _searchQuery = '';
  Map<String, dynamic> _currentFilters = {
    'dateRange': 'Todos',
    'videoStyle': 'Todos',
    'status': 'Todos',
    'sortBy': 'Más reciente',
    'favoritesOnly': false,
  };

  // Mock video data
  final List<Map<String, dynamic>> _allVideos = [
    {
      "id": "1",
      "thumbnail":
          "https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": "0:15",
      "status": "completed",
      "createdAt": "19 Ago 2025",
      "isFavorite": true,
      "title": "Video cinematográfico IA",
      "style": "Cinematográfico",
      "prompt": "Una puesta de sol épica sobre montañas",
    },
    {
      "id": "2",
      "thumbnail":
          "https://images.pixabay.com/photo/2016/02/01/00/56/news-1172463_640.jpg",
      "duration": "0:30",
      "status": "processing",
      "createdAt": "18 Ago 2025",
      "isFavorite": false,
      "title": "Animación futurista",
      "style": "Animación",
      "prompt": "Ciudad futurista con luces neón",
    },
    {
      "id": "3",
      "thumbnail":
          "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&auto=format&fit=crop&q=60",
      "duration": "0:12",
      "status": "completed",
      "createdAt": "17 Ago 2025",
      "isFavorite": true,
      "title": "Naturaleza realista",
      "style": "Realista",
      "prompt": "Bosque mágico con rayos de sol",
    },
    {
      "id": "4",
      "thumbnail":
          "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": "0:25",
      "status": "failed",
      "createdAt": "16 Ago 2025",
      "isFavorite": false,
      "title": "Arte abstracto",
      "style": "Artístico",
      "prompt": "Formas abstractas en movimiento",
    },
    {
      "id": "5",
      "thumbnail":
          "https://images.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_640.jpg",
      "duration": "0:20",
      "status": "completed",
      "createdAt": "15 Ago 2025",
      "isFavorite": false,
      "title": "Vintage espacial",
      "style": "Vintage",
      "prompt": "Exploración espacial retro",
    },
    {
      "id": "6",
      "thumbnail":
          "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&auto=format&fit=crop&q=60",
      "duration": "0:18",
      "status": "completed",
      "createdAt": "14 Ago 2025",
      "isFavorite": true,
      "title": "Paisaje cinematográfico",
      "style": "Cinematográfico",
      "prompt": "Montañas nevadas al amanecer",
    },
  ];

  List<Map<String, dynamic>> _filteredVideos = [];

  @override
  void initState() {
    super.initState();
    _filteredVideos = List.from(_allVideos);
    _scrollController.addListener(_onScroll);
    _loadMoreVideos();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _loadMoreVideos();
    }
  }

  Future<void> _loadMoreVideos() async {
    if (_isLoading || !_hasMoreVideos) return;

    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
      // For demo purposes, we'll stop loading after initial load
      _hasMoreVideos = false;
    });
  }

  Future<void> _refreshVideos() async {
    HapticFeedback.lightImpact();
    setState(() {
      _isLoading = true;
    });

    // Simulate refresh
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
      _filteredVideos = List.from(_allVideos);
      _hasMoreVideos = true;
    });
  }

  void _applyFilters() {
    setState(() {
      _filteredVideos = _allVideos.where((video) {
        // Apply search filter
        if (_searchQuery.isNotEmpty) {
          final searchLower = _searchQuery.toLowerCase();
          if (!(video["title"] as String).toLowerCase().contains(searchLower) &&
              !(video["style"] as String).toLowerCase().contains(searchLower) &&
              !(video["createdAt"] as String)
                  .toLowerCase()
                  .contains(searchLower)) {
            return false;
          }
        }

        // Apply style filter
        if (_currentFilters['videoStyle'] != 'Todos' &&
            video["style"] != _currentFilters['videoStyle']) {
          return false;
        }

        // Apply status filter
        if (_currentFilters['status'] != 'Todos') {
          final statusMap = {
            'Completado': 'completed',
            'Procesando': 'processing',
            'Fallido': 'failed',
          };
          if (video["status"] != statusMap[_currentFilters['status']]) {
            return false;
          }
        }

        // Apply favorites filter
        if (_currentFilters['favoritesOnly'] == true &&
            video["isFavorite"] != true) {
          return false;
        }

        return true;
      }).toList();

      // Apply sorting
      switch (_currentFilters['sortBy']) {
        case 'Más antiguo':
          _filteredVideos.sort((a, b) =>
              (a["createdAt"] as String).compareTo(b["createdAt"] as String));
          break;
        case 'Más gustados':
          _filteredVideos.sort((a, b) => (b["isFavorite"] as bool ? 1 : 0)
              .compareTo(a["isFavorite"] as bool ? 1 : 0));
          break;
        case 'Más reciente':
        default:
          _filteredVideos.sort((a, b) =>
              (b["createdAt"] as String).compareTo(a["createdAt"] as String));
          break;
      }
    });
  }

  void _toggleVideoSelection(Map<String, dynamic> video) {
    setState(() {
      if (_selectedVideos.any((v) => v["id"] == video["id"])) {
        _selectedVideos.removeWhere((v) => v["id"] == video["id"]);
      } else {
        _selectedVideos.add(video);
      }

      if (_selectedVideos.isEmpty) {
        _isMultiSelectMode = false;
      }
    });
  }

  void _toggleFavorite(Map<String, dynamic> video) {
    setState(() {
      final index = _allVideos.indexWhere((v) => v["id"] == video["id"]);
      if (index != -1) {
        _allVideos[index]["isFavorite"] =
            !(_allVideos[index]["isFavorite"] as bool);
      }
      _applyFilters();
    });
  }

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheetWidget(
        currentFilters: _currentFilters,
        onFiltersApplied: (filters) {
          setState(() {
            _currentFilters = filters;
          });
          _applyFilters();
        },
      ),
    );
  }

  void _exitMultiSelectMode() {
    setState(() {
      _isMultiSelectMode = false;
      _selectedVideos.clear();
    });
  }

  void _deleteSelectedVideos() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminar videos'),
        content: Text(
            '¿Estás seguro de que quieres eliminar ${_selectedVideos.length} video${_selectedVideos.length != 1 ? 's' : ''}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                for (final video in _selectedVideos) {
                  _allVideos.removeWhere((v) => v["id"] == video["id"]);
                }
                _selectedVideos.clear();
                _isMultiSelectMode = false;
              });
              _applyFilters();
              Navigator.of(context).pop();
            },
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  void _shareSelectedVideos() {
    // Implement share functionality
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Compartiendo ${_selectedVideos.length} video${_selectedVideos.length != 1 ? 's' : ''}...'),
        duration: const Duration(seconds: 2),
      ),
    );
    _exitMultiSelectMode();
  }

  void _favoriteSelectedVideos() {
    setState(() {
      for (final selectedVideo in _selectedVideos) {
        final index =
            _allVideos.indexWhere((v) => v["id"] == selectedVideo["id"]);
        if (index != -1) {
          _allVideos[index]["isFavorite"] = true;
        }
      }
      _selectedVideos.clear();
      _isMultiSelectMode = false;
    });
    _applyFilters();
  }

  bool _hasActiveFilters() {
    return _currentFilters['dateRange'] != 'Todos' ||
        _currentFilters['videoStyle'] != 'Todos' ||
        _currentFilters['status'] != 'Todos' ||
        _currentFilters['sortBy'] != 'Más reciente' ||
        _currentFilters['favoritesOnly'] == true;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Historial de Videos',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                  if (!_isMultiSelectMode)
                    GestureDetector(
                      onTap: () {
                        HapticFeedback.lightImpact();
                        Navigator.pushNamed(context, '/video-creation-screen');
                      },
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: colorScheme.secondary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: CustomIconWidget(
                          iconName: 'add',
                          color: colorScheme.onSecondary,
                          size: 5.w,
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Search bar
            if (!_isMultiSelectMode)
              SearchBarWidget(
                onSearchChanged: (query) {
                  setState(() {
                    _searchQuery = query;
                  });
                  _applyFilters();
                },
                onFilterPressed: _showFilterBottomSheet,
                showFilterBadge: _hasActiveFilters(),
              ),

            // Content
            Expanded(
              child: _filteredVideos.isEmpty
                  ? EmptyStateWidget(
                      onCreateVideo: () {
                        Navigator.pushNamed(context, '/video-creation-screen');
                      },
                    )
                  : RefreshIndicator(
                      onRefresh: _refreshVideos,
                      child: GridView.builder(
                        controller: _scrollController,
                        padding: EdgeInsets.all(2.w),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 9 / 16,
                          crossAxisSpacing: 2.w,
                          mainAxisSpacing: 2.w,
                        ),
                        itemCount:
                            _filteredVideos.length + (_isLoading ? 2 : 0),
                        itemBuilder: (context, index) {
                          if (index >= _filteredVideos.length) {
                            return _buildSkeletonThumbnail();
                          }

                          final video = _filteredVideos[index];
                          final isSelected = _selectedVideos
                              .any((v) => v["id"] == video["id"]);

                          return VideoThumbnailWidget(
                            video: video,
                            isSelected: isSelected,
                            isMultiSelectMode: _isMultiSelectMode,
                            onTap: () {
                              if (_isMultiSelectMode) {
                                _toggleVideoSelection(video);
                              } else {
                                // Navigate to video preview
                                HapticFeedback.lightImpact();
                                // Navigator.pushNamed(context, '/video-preview-screen', arguments: video);
                              }
                            },
                            onLongPress: () {
                              if (!_isMultiSelectMode) {
                                setState(() {
                                  _isMultiSelectMode = true;
                                  _selectedVideos.add(video);
                                });
                              }
                            },
                            onFavoriteToggle: () => _toggleFavorite(video),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),

      // Bulk action toolbar
      bottomNavigationBar: _isMultiSelectMode
          ? BulkActionToolbarWidget(
              selectedCount: _selectedVideos.length,
              onCancel: _exitMultiSelectMode,
              onDelete: _deleteSelectedVideos,
              onShare: _shareSelectedVideos,
              onFavorite: _favoriteSelectedVideos,
            )
          : CustomBottomBar(
              currentIndex: 1,
              onTap: (index) {
                switch (index) {
                  case 0:
                    Navigator.pushNamed(context, '/video-creation-screen');
                    break;
                  case 1:
                    // Already on history screen
                    break;
                  case 2:
                    Navigator.pushNamed(context, '/subscription-screen');
                    break;
                }
              },
            ),
    );
  }

  Widget _buildSkeletonThumbnail() {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: EdgeInsets.all(1.w),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: AspectRatio(
          aspectRatio: 9 / 16,
          child: Container(
            color: colorScheme.outline.withValues(alpha: 0.1),
            child: Center(
              child: CircularProgressIndicator(
                color: colorScheme.secondary,
                strokeWidth: 2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
