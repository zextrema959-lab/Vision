import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class BulkActionToolbarWidget extends StatelessWidget {
  final int selectedCount;
  final VoidCallback? onDelete;
  final VoidCallback? onShare;
  final VoidCallback? onFavorite;
  final VoidCallback? onCancel;

  const BulkActionToolbarWidget({
    super.key,
    required this.selectedCount,
    this.onDelete,
    this.onShare,
    this.onFavorite,
    this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: 12.h,
      decoration: BoxDecoration(
        color: colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Row(
            children: [
              // Cancel button
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  onCancel?.call();
                },
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  child: CustomIconWidget(
                    iconName: 'close',
                    color: colorScheme.onSurface,
                    size: 6.w,
                  ),
                ),
              ),

              SizedBox(width: 4.w),

              // Selected count
              Expanded(
                child: Text(
                  '$selectedCount video${selectedCount != 1 ? 's' : ''} seleccionado${selectedCount != 1 ? 's' : ''}',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              // Action buttons
              Row(
                children: [
                  _buildActionButton(
                    context,
                    'favorite',
                    'Favorito',
                    colorScheme.secondary,
                    onFavorite,
                  ),
                  SizedBox(width: 4.w),
                  _buildActionButton(
                    context,
                    'share',
                    'Compartir',
                    colorScheme.secondary,
                    onShare,
                  ),
                  SizedBox(width: 4.w),
                  _buildActionButton(
                    context,
                    'delete',
                    'Eliminar',
                    Colors.red,
                    onDelete,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context,
    String iconName,
    String tooltip,
    Color color,
    VoidCallback? onPressed,
  ) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onPressed?.call();
      },
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: CustomIconWidget(
          iconName: iconName,
          color: color,
          size: 5.w,
        ),
      ),
    );
  }
}
