import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

class FilterBottomSheetWidget extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onFiltersApplied;

  const FilterBottomSheetWidget({
    super.key,
    required this.currentFilters,
    required this.onFiltersApplied,
  });

  @override
  State<FilterBottomSheetWidget> createState() =>
      _FilterBottomSheetWidgetState();
}

class _FilterBottomSheetWidgetState extends State<FilterBottomSheetWidget> {
  late Map<String, dynamic> _filters;

  final List<String> _dateRanges = [
    'Todos',
    'Hoy',
    'Esta semana',
    'Este mes',
    'Últimos 3 meses',
  ];

  final List<String> _videoStyles = [
    'Todos',
    'Cinematográfico',
    'Animación',
    'Realista',
    'Artístico',
    'Vintage',
  ];

  final List<String> _statusOptions = [
    'Todos',
    'Completado',
    'Procesando',
    'Fallido',
  ];

  final List<String> _sortOptions = [
    'Más reciente',
    'Más antiguo',
    'Más gustados',
    'Visto recientemente',
  ];

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.symmetric(vertical: 2.h),
            decoration: BoxDecoration(
              color: colorScheme.outline.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: _resetFilters,
                  child: Text(
                    'Limpiar',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.secondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Text(
                  'Filtros',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextButton(
                  onPressed: _applyFilters,
                  child: Text(
                    'Aplicar',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: colorScheme.secondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          Divider(
            color: colorScheme.outline.withValues(alpha: 0.2),
            height: 1,
          ),

          // Filter content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFilterSection(
                    context,
                    'Rango de fechas',
                    _dateRanges,
                    _filters['dateRange'] as String? ?? 'Todos',
                    (value) => _filters['dateRange'] = value,
                  ),

                  SizedBox(height: 4.h),

                  _buildFilterSection(
                    context,
                    'Estilo de video',
                    _videoStyles,
                    _filters['videoStyle'] as String? ?? 'Todos',
                    (value) => _filters['videoStyle'] = value,
                  ),

                  SizedBox(height: 4.h),

                  _buildFilterSection(
                    context,
                    'Estado',
                    _statusOptions,
                    _filters['status'] as String? ?? 'Todos',
                    (value) => _filters['status'] = value,
                  ),

                  SizedBox(height: 4.h),

                  _buildFilterSection(
                    context,
                    'Ordenar por',
                    _sortOptions,
                    _filters['sortBy'] as String? ?? 'Más reciente',
                    (value) => _filters['sortBy'] = value,
                  ),

                  SizedBox(height: 4.h),

                  // Favorites only toggle
                  _buildToggleSection(
                    context,
                    'Solo favoritos',
                    _filters['favoritesOnly'] as bool? ?? false,
                    (value) => _filters['favoritesOnly'] = value,
                  ),

                  SizedBox(height: 8.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection(
    BuildContext context,
    String title,
    List<String> options,
    String selectedValue,
    Function(String) onChanged,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        Wrap(
          spacing: 2.w,
          runSpacing: 2.w,
          children: options.map((option) {
            final isSelected = option == selectedValue;

            return GestureDetector(
              onTap: () {
                HapticFeedback.lightImpact();
                setState(() {
                  onChanged(option);
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.w),
                decoration: BoxDecoration(
                  color:
                      isSelected ? colorScheme.secondary : colorScheme.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? colorScheme.secondary
                        : colorScheme.outline.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Text(
                  option,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: isSelected
                        ? colorScheme.onSecondary
                        : colorScheme.onSurface,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildToggleSection(
    BuildContext context,
    String title,
    bool value,
    Function(bool) onChanged,
  ) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        Switch(
          value: value,
          onChanged: (newValue) {
            HapticFeedback.lightImpact();
            setState(() {
              onChanged(newValue);
            });
          },
          activeColor: colorScheme.secondary,
        ),
      ],
    );
  }

  void _resetFilters() {
    HapticFeedback.lightImpact();
    setState(() {
      _filters = {
        'dateRange': 'Todos',
        'videoStyle': 'Todos',
        'status': 'Todos',
        'sortBy': 'Más reciente',
        'favoritesOnly': false,
      };
    });
  }

  void _applyFilters() {
    HapticFeedback.lightImpact();
    widget.onFiltersApplied(_filters);
    Navigator.of(context).pop();
  }
}
